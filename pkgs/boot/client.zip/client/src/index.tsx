import { start } from 'web-init'
import './index.css'
import baseUrl from './baseurl'

console.log('wowow')
start({
  baseUrl,
})
