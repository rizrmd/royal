import { defineConfig } from 'vite'
import { VitePWA } from 'vite-plugin-pwa'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  build: {
    outDir: './build',
    emptyOutDir: true,
  },
  plugins: [
    VitePWA({
      workbox: {
        cleanupOutdatedCaches: false,
      },
    }),
    react({
      include: ['./src', './public'],
      jsxRuntime: 'classic',
      fastRefresh: true,
      babel: {
        presets: [
          [
            '@babel/preset-react',
            {
              pragma: 'jsx', // default pragma is React.createElement (only in classic runtime)
              pragmaFrag: 'Fragment', // default is React.Fragment (only in classic runtime)
              throwIfNamespace: false, // defaults to true
              runtime: 'classic', // defaults to classic
              // "importSource": "custom-jsx-library" // defaults to react (only in automatic runtime)
            },
          ],
        ],
      },
    }),
  ],
})
