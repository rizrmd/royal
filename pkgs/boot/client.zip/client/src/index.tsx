import { start } from 'web-init'
import './index.css'
import baseUrl from './baseurl'

start({
  baseUrl,
})
