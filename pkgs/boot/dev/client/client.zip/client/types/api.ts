import hash from "../src/api/hash";

export default {
  hash: hash,
};
