import { defineConfig } from 'vite'
import { VitePWA } from 'vite-plugin-pwa'
import react from '@vitejs/plugin-react'
import { babel } from '@rollup/plugin-babel'

// https://vitejs.dev/config/
export default defineConfig({
  build: {
    outDir: './build',
    emptyOutDir: true,
    target: 'es2015',
    manifest: true,
  },
  plugins: [
    VitePWA({
      workbox: {
        cleanupOutdatedCaches: true,
      },
    }),
    react({
      jsxRuntime: 'classic',
      fastRefresh: true,
      babel: {
        presets: [
          [
            '@babel/preset-react',
            {
              pragma: 'jsx',
              pragmaFrag: 'Fragment',
              throwIfNamespace: false,
              runtime: 'classic',
            },
          ],
        ],
      },
    }),
  ],
})
