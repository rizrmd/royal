import { page } from 'web-init'

export default page({
  url: '/create-sekolah',
  component: ({ layout }) => {
    return <></>
  },
})
