export default {
  blank: () => import("../src/base/layout/blank"),
  default: () => import("../src/base/layout/default"),
};
