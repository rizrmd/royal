module.exports = {
  content: ['.src/**/*.{jsx,tsx}', 'index.html'],
  plugins: [],
}
