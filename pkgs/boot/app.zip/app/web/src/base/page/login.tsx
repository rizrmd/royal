import { Login1 } from 'theme'
import { page } from 'web-init'
import { Form } from 'web-ui'
import { useAuth } from 'web-utils'

export default page({
  url: '/login',
  layout: 'blank',
  component: () => {
    const auth = useAuth({
      onReady: () => {
        if (auth.user.role !== 'guest') {
          navigate('/')
        }
      },
    })

    if (!auth.ready)
      return (
        <div className="flex w-full h-full items-center justify-center">
          Loading...
        </div>
      )

    return (
      <Login1>
        <Form
          schema={{
            fields: {
              username: {},
              password: {
                type: 'password',
              },
            },
          }}
          onSubmit={async (ctx) => {
            const { data } = ctx
            if (data.username === 'admin' && data.password === 'admin') {
              await auth.login({
                username: data.username,
                password: data.password,
              })
              navigate('/')
            } else {
              alert('Login salah')
            }
          }}
          layout={[
            'username',
            'password',
            (ctx) => (
              <button
                type="submit"
                className="btn btn-primary m-2"
                onClick={() => {
                  ctx.submit()
                }}
              >
                Submit
              </button>
            ),
          ]}
        />
      </Login1>
    )
  },
})
