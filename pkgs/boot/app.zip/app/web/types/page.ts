export default {
  'home':["/", "default", () => import('../src/base/page/home')],
}