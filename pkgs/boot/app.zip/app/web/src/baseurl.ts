import { IBaseUrl } from 'web-init'

export default (props: IBaseUrl) => {
  return `http://localhost:3200/`
}
