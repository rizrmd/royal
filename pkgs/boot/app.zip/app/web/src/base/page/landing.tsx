import { useEffect } from 'react'
import { Layout1 } from 'theme'
import { page } from 'web-init'
import { useAuth, useLocal } from 'web-utils'

export default page({
  url: '/',
  component: ({ layout }) => {
    const local = useLocal(
      {
        sekolah: {
          loading: true,
          count: 0,
          mumtaz: {} as any,
        },
      },
      async () => {
        // local.sekolah.count = await db.schools.count()
        // local.sekolah.mumtaz = await db.schools.findFirst({
        //   where: {
        //     name: {
        //       contains: 'mumtaz',
        //       mode: 'insensitive',
        //     },
        //   },
        // })
        // local.sekolah.loading = false
        // local.render()
      }
    )

    return (
      <pre>
        {local.sekolah.loading ? (
          'Masih loading'
        ) : (
          <>
            Sekolah: {local.sekolah.count}
            <br />
            Sekolah Mumtaz:
            {JSON.stringify(local.sekolah.mumtaz, null, 2)}
          </>
        )}
      </pre>
    )
  },
})
