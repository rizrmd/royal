import { useEffect } from 'react'
import { Layout1 } from 'theme'
import { layout } from 'web-init'
import { useAuth } from 'web-utils'

export default layout({
  component: ({ children }) => {
    const auth = useAuth({
      onReady: () => {
        // console.log(auth.user.role)
        if (auth.user.role === 'guest') {
          navigate('/login')
        }
      },
    })
		if(auth.ready === false || auth.user.role === 'guest') return null
		console.log(auth.ready)
    return (
      <Layout1
        sidebar={
          auth.ready ? (
            <div className='flex flex-col gap-y-3'>
              <a href="/">ke home</a>
              <a href="/create-sekolah">Create Sekolah</a>
              <a
                class="btn btn-primary cursor-pointer"
                onClick={async () => {
                  await auth.logout()
                  navigate('/login')
                }}
              >
                Logout
              </a>
            </div>
          ) : (
            <>
              Loading sidebar...
            </>
          )
        }
      >
        {children}
      </Layout1>
    )
  },
})
