export const pages = {
  'create-sekolah':["/create-sekolah", "default", () => import('../src/base/page/create-sekolah')],
  'landing':["/", "default", () => import('../src/base/page/landing')],
  'login':["/login", "blank", () => import('../src/base/page/login')],
}